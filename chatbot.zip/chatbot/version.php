<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_chatbot';
$plugin->version = 2025070209;
$plugin->requires = 2019052000; // Moodle 3.7.
